// Define all the types of tokens our parser can understand
public enum TokenType {
    NUMBER, PLUS, MINUS, MUL, DIV, LPAREN, RPAREN, EOF
}
